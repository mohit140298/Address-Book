import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

public class AdminPage extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public AdminPage() {
		setTitle("AdminPage");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setBounds(100, 100, 580, 406);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBackground(Color.PINK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnAddnewcontact = new JButton("Add New Conatct");
		btnAddnewcontact.setForeground(Color.BLUE);
		btnAddnewcontact.setBackground(UIManager.getColor("Button.background"));
		btnAddnewcontact.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		btnAddnewcontact.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addcontact_page obj=new addcontact_page();
				obj.setVisible(true);
				dispose();
			}
		});
		
		JButton btnDeleteContact = new JButton("Delete Contact");
		btnDeleteContact.setForeground(Color.BLUE);
		btnDeleteContact.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		btnDeleteContact.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				deletecontact_page obj =new deletecontact_page();
				obj.setVisible(true);
				dispose();
			}
		});
		
		JButton btnUpdateContact = new JButton("Update Contact");
		btnUpdateContact.setForeground(Color.BLUE);
		btnUpdateContact.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		btnUpdateContact.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new update_contact().setVisible(true);
				dispose();
			}
		});
		
		JButton btnSearchContact = new JButton("Search Contact");
		btnSearchContact.setForeground(Color.BLUE);
		btnSearchContact.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		btnSearchContact.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Search_contact().setVisible(true);
				dispose();
			}
		});
		
		JButton btnSendContact = new JButton("send contact");
		btnSendContact.setForeground(Color.BLUE);
		btnSendContact.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		btnSendContact.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new send_contact().setVisible(true);
				dispose();
			}
		});
		
		JButton btnLogOut = new JButton("Log out");
		btnLogOut.setForeground(Color.BLUE);
		btnLogOut.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Login_page().setVisible(true);
				dispose();
				
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnSendContact, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE)
						.addComponent(btnAddnewcontact, GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnUpdateContact, GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
							.addComponent(btnLogOut, GroupLayout.PREFERRED_SIZE, 223, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(btnSearchContact, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnDeleteContact, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE))))
					.addGap(26))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAddnewcontact, GroupLayout.PREFERRED_SIZE, 66, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnDeleteContact, GroupLayout.PREFERRED_SIZE, 71, GroupLayout.PREFERRED_SIZE))
					.addGap(46)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnUpdateContact, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnSearchContact, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE))
					.addGap(46)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(btnSendContact, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnLogOut, GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE))
					.addContainerGap(35, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

}
