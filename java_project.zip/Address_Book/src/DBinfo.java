import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBinfo {
	private static Connection con;
	  static
	  {
		  //load driver
		  try 
		  {
			Class.forName("com.mysql.jdbc.Driver");
		   } 
		  catch (ClassNotFoundException e) 
		  {
			
			e.printStackTrace();
		  }
	  }
	  public static Connection getConn()
	  {
		  try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pdb", "root", "rat");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  return con;
	  }

}
