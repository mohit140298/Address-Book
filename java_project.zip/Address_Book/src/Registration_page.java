import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.Color;

public class Registration_page extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	
	public void reset()
	{
		textField.setText(null);
		textField_1.setText(null);
		textField_2.setText(null);
		passwordField.setText(null);
		passwordField_1.setText(null);
		comboBox.setSelectedIndex(0);
	}
	public Registration_page() {
		setTitle("Registration page");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setBounds(100, 100, 453, 495);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLUE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblRegistration = new JLabel("Registration");
		lblRegistration.setForeground(Color.PINK);
		lblRegistration.setBackground(Color.WHITE);
		lblRegistration.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		
		JLabel lblName = new JLabel("name");
		lblName.setForeground(Color.PINK);
		lblName.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField.setColumns(10);
		
		JLabel lblUsername = new JLabel("username");
		lblUsername.setForeground(Color.PINK);
		lblUsername.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_1.setColumns(10);
		
		JLabel lblEmail = new JLabel("email");
		lblEmail.setForeground(Color.PINK);
		lblEmail.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_2.setColumns(10);
		
		JLabel lblPassword = new JLabel("password");
		lblPassword.setForeground(Color.PINK);
		lblPassword.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		JLabel lblConfirmPassword = new JLabel("confirm password");
		lblConfirmPassword.setForeground(Color.PINK);
		lblConfirmPassword.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		JButton btnSave = new JButton("save");
		btnSave.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String name=textField.getText();
				String username=textField_1.getText();
				String email=textField_2.getText();
				String password=String.copyValueOf(passwordField.getPassword());
				String repassword=String.copyValueOf(passwordField_1.getPassword());
				String usertype=(String) comboBox.getSelectedItem();
				if(name.length()==0||username.length()==0||email.length()==0||password.length()==0||repassword.length()==0||usertype.length()==0)
				{
					JOptionPane.showMessageDialog(Registration_page.this, "please fill all the fields", "Error", JOptionPane.ERROR_MESSAGE);
				}
				else
				{
				  if(password.equals(repassword))
				  {
				    Connection con=DBinfo.getConn();
				    String query="insert into registration values(?,?,?,?,?,?)";
				    int i=0;
				    try 
				    {
					  PreparedStatement ps=con.prepareStatement(query);
					  ps.setInt(1, 0);
					  ps.setString(2, name);
					  ps.setString(3, username);
					  ps.setString(4, email);
					  ps.setString(5, password);
					  ps.setString(6, usertype);
					  i=ps.executeUpdate();
				     }
				    catch (SQLException e)
				    {
					// TODO Auto-generated catch block
					e.printStackTrace();
				    }
				    if(i!=0)
					{
						JOptionPane.showMessageDialog(Registration_page.this, "registration done!","success",JOptionPane.INFORMATION_MESSAGE);
						reset();
					}
					if(i==0)
					{
						JOptionPane.showMessageDialog(Registration_page.this, "registration failed","Error",JOptionPane.ERROR_MESSAGE);
					}
				  }
				  else
				  {
					  JOptionPane.showMessageDialog(Registration_page.this, "passwords does not match", "Error", JOptionPane.ERROR_MESSAGE);
				  }
				
				}
			}	
		});
		
		JButton btnReset = new JButton("log in");
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Login_page().setVisible(true);
				dispose();
			}
		});
		
		JButton btnNewButton = new JButton("cancel");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				new Login_page().setVisible(true);
			}
		});
		
		JLabel lblUsertype = new JLabel("usertype");
		lblUsertype.setForeground(Color.PINK);
		lblUsertype.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		String values[]= {"admin","user"};
		
		comboBox = new JComboBox(values);
		comboBox.setForeground(Color.BLACK);
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 13));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(67)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblUsername)
						.addComponent(lblName)
						.addComponent(lblEmail)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
							.addComponent(btnSave)
							.addComponent(lblConfirmPassword))
						.addComponent(lblPassword))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(25)
							.addComponent(btnReset)
							.addPreferredGap(ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
							.addComponent(btnNewButton)
							.addGap(41))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(38)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(passwordField_1)
								.addComponent(textField_2)
								.addComponent(textField_1)
								.addComponent(textField)
								.addComponent(passwordField, Alignment.TRAILING)
								.addComponent(comboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addContainerGap(152, Short.MAX_VALUE))))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(164)
					.addComponent(lblRegistration)
					.addContainerGap(205, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(114)
					.addComponent(lblUsertype)
					.addContainerGap(270, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblRegistration)
					.addGap(29)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblName)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(40)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblUsername)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(44)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblEmail)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(34)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPassword)
						.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(27)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblConfirmPassword)
						.addComponent(passwordField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(29)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblUsertype)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnSave)
						.addComponent(btnReset))
					.addGap(29))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
